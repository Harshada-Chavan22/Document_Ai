DEALER_MASTER = [
    "ABC Tractors",
    "Shivam Tractors",
    "Mahindra Tractors Pvt Ltd",
    "Patil Tractors",
    "Kisan Tractor Agency"
]
